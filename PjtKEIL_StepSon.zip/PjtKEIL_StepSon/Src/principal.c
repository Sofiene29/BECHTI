

#include "DriverJeuLaser.h"

void timer_callback(void);

int main(void)
{
//LongueurSon	 DCD 5512 
//PeriodeSonMicroSec	 DCD 91 
// ===========================================================================
// ============= INIT PERIPH (faites qu'une seule fois)  =====================
// ===========================================================================

// Apr�s ex�cution : le coeur CPU est clock� � 72MHz ainsi que tous les timers
CLOCK_Configure();

//**T = x*TCk = x*1/72Mhz=91�s // 
//Fpwm=72MHz/720 
	
	
Timer_1234_Init_ff(TIM4,6552);	
Active_IT_Debordement_Timer( TIM4, 2, timer_callback );	
	

Timer_1234_Init_ff(TIM3,720);	
Active_IT_Debordement_Timer( TIM3, 2, timer_callback );	
//============================================================================	
	char GPIO_Configure(GPIOB, 0, OUTPUT, ALT_PPULL);
	
while	(1)
	{
	}
}

